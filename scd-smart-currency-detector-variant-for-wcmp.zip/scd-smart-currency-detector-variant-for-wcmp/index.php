<?php
/*
  Plugin Name: SCD - Smart Currency Detector Variant for WCMP
  Plugin URI: http://gajelabs.com/product/scd
  Description: This wordpress / woocommerce plugin is an ALL-IN-ONE solution for online market places owners, sellers, end customers. Multivendors variant
  Version: 1.0.0
  WC tested up to: 5.9
  Author: GaJeLabs
  Author URI: http://gajelabs.com
 */

if (in_array('scd-smart-currency-detector/index.php', apply_filters('active_plugins', get_option('active_plugins')))){ 
include 'scd_multivendors_renders.php';
require 'scd_wcmp_multivendor.php';
include 'includes/index.php';
}


define( 'SCDS_PLUGIN_DIR_PATH', plugin_dir_path( __FILE__ ) );

function scds_add_script_to_admin_dashboard() {
    
    $cur_screen = get_current_screen();
    wp_enqueue_script("scds-script", trailingslashit(plugins_url("", __FILE__)) . "js/scd_lic_form.js", array("jquery"));
}

add_action('current_screen', 'scds_add_script_to_admin_dashboard');

function scd_multi_add_scrypt_topost() {
    wp_enqueue_script("scd-wcmp-multivendor", trailingslashit(plugins_url("", __FILE__)) . "js/scd_wcmp_multivendor.js", array("jquery"));
    $variable_to_post = [
       'ajax_url' => admin_url('admin-ajax.php') 
    ];
    wp_localize_script('scd-wcmp-multivendor', 'scd_ajax', $variable_to_post);
}
add_action('wp_enqueue_scripts', 'scd_multi_add_scrypt_topost');


function scd_get_slm_info(){
    return json_decode(file_get_contents(SCDS_PLUGIN_DIR_PATH . "slm.json"));
}

add_action('admin_notices','scd_premium_require');
function scd_premium_require() {
if(!is_plugin_active('scd-smart-currency-detector/index.php')){
    echo '<h3 style="color:red;">SCD Multivendors PRO require scd-smart-currency-detector before use, please <a target="__blank" href="https://wordpress.org/plugins/scd-smart-currency-detector/"> download and install it here</a><h3>';    
}
}


  

